﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizeLibrary.Constants
{
    public class RoleConstants
    {
        //Roles constants
        public static List<string> rolesList() => new List<string> { SuperAdmin, Admin, Basc };
        public const string SuperAdmin = "Super_Admin";
        public const string Admin = "Admin";
        public const string Basc = "Basc";
    }
}
