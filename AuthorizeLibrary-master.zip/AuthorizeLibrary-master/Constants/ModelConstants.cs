﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizeLibrary.Constants
{
    public class ModelConstants
    {
        public const string Products = "Products";
        public const string Stock = "Stock";
        public const string Item = "Item";
        public const string Customer = "Customer";
        public const string Test = "Test";
        public static List<string> ModelList() =>
            new List<string> { Products, Stock, Item, Customer, Test };
    }
}
